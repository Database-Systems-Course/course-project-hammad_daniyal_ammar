﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project
{
    public partial class d_main_page : Form
    {
        SqlConnection con1;
        public int doctorID = 0;
        public d_main_page()
        {
            InitializeComponent();
        }

        private void Timings_Click(object sender, EventArgs e)
        {

        }

        private void registerasdoctor_clinic1_gbx_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void doctorhome_sendapp_b_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void d_main_page_Load(object sender, EventArgs e)
        {
            //con1 = new SqlConnection("Data Source =.; Initial Catalog = PMS; User ID = sa; Password=Habib123##"); 
            con1 = new SqlConnection(@"Data Source=DESKTOP-PGBON6F;Initial Catalog=AppointmentProj;Integrated Security=SSPI;User ID=DESKTOP-PGBON6F\HP;Password=");
            //public SqlCommand cmd = new SqlCommand(); 
            con1.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select DoctorName from Doctor where idDoctor = " + doctorID;
            d_main_doctor_name_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select Contactno from Doctor where idDoctor = " + doctorID;
            d_main_number_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select emailID from Doctor where idDoctor = " + doctorID;
            d_main_email_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select address from Doctor where idDoctor = " + doctorID;
            d_main_doctor_address_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select gender from Doctor where idDoctor = " + doctorID;
            string gender = cmd.ExecuteScalar().ToString();
            if (gender == "m")
            {
                d_main_gender_m_rb.Checked = true;
            }
            else if (gender == "f")
            {
                d_main_gender_f_rb.Checked = true;
            }
            else if (gender == "o")
            {
                d_main_gender_o_rb.Checked = true;
            }

            try
            {
                cmd.CommandText = "select qualification from Doctor where idDoctor = " + doctorID;
                d_main_Qualification_tbx.Text = cmd.ExecuteScalar().ToString();
            }
            catch
            {
                d_main_Qualification_tbx.Text = "";
            }
            try
            {
                cmd.CommandText = "select specialization from Doctor where idDoctor = " + doctorID;
                d_main_specialization_tbx.Text = cmd.ExecuteScalar().ToString();
            }
            catch
            {
                d_main_specialization_tbx.Text = "";
            }
            try
            {
                cmd.CommandText = "select distinct ClinicName from Clinic c, Clinic_has_Doctor cd where c.idClinic=cd.Clinic_idClinic and Doctor_idDoctor=" + doctorID;
                SqlDataReader sqlReader = cmd.ExecuteReader();
                while (sqlReader.Read())
                {
                    d_main_clinic_combo.Items.Add(sqlReader["clinicname"].ToString());
                }
                sqlReader.Close();
            }
            catch
            {

            }
            try
            {
                cmd.CommandText = "select distinct ClinicName from Clinic c, Clinic_has_Doctor cd where c.idClinic=cd.Clinic_idClinic";
                SqlDataReader sqlReader = cmd.ExecuteReader();
                while (sqlReader.Read())
                {
                    d_main_clinic_name_combo.Items.Add(sqlReader["clinicname"].ToString());
                }
                sqlReader.Close();
            }
            catch
            {

            }
            cmd.CommandText = "select idappointment, appdatentime from Appointment where AppDatenTime > getdate() and ConfirmationStatus = 'confirmed' and Doctor_idDoctor =" + doctorID;
            SqlDataReader sqlReader2 = cmd.ExecuteReader();
            while (sqlReader2.Read())
            {
                Appointments.Items.Add("appointment id : " + sqlReader2["idappointment"].ToString() + " -- Date n Time" + sqlReader2["appdatentime"].ToString());
            }
            sqlReader2.Close();
            cmd.CommandText = "select idappointment, appdatentime from Appointment where AppDatenTime < getdate() and ConfirmationStatus = 'confirmed' and Doctor_idDoctor =" + doctorID;
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds, "SearchResult");
            schedulegrid.DataSource = ds.Tables["SearchResult"];
            schedulegrid.Refresh();
            cmd.CommandText = "select ClinicName, WeekDay, OpeningTime, endTime from clinic c, clinic_has_doctor cd where c.idclinic = cd.Clinic_idClinic and Doctor_idDoctor =" + doctorID;
            SqlDataAdapter adapter2 = new SqlDataAdapter(cmd);
            DataSet ds2 = new DataSet();
            adapter.Fill(ds2, "SearchResult");
            doctortimings.DataSource = ds2.Tables["SearchResult"];
            doctortimings.Refresh();
            d_main_weekday_combo.Items.Add("Monday");
            d_main_weekday_combo.Items.Add("Tuesday");
            d_main_weekday_combo.Items.Add("Wednesday");
            d_main_weekday_combo.Items.Add("Thursday");
            d_main_weekday_combo.Items.Add("Friday");
            //d_main_weekday_combo.Items.Add("Saturday");
            //d_main_weekday_combo.Items.Add("Sunday");
            d_main_doctor_name_tbx.Enabled = false;
            d_main_number_tbx.Enabled = false;
            d_main_email_tbx.Enabled = false;
            d_main_doctor_address_tbx.Enabled = false;
            d_main_Qualification_tbx.Enabled = false;
            d_main_specialization_tbx.Enabled = false;
            d_main_gender_m_rb.Enabled = false;
            d_main_gender_f_rb.Enabled = false;
            d_main_gender_o_rb.Enabled = false;
            d_main_clinic_address_tbx.Enabled = false;
            d_main_clinicID_tbx.Enabled = false;
            registerasdoctor_clinic1_time1.Enabled = false;
            registerasdoctor_clinic1_time2.Enabled = false;
            d_main_nositting_cbx.Enabled = false;
            d_main_patient_name_tbx.Enabled = false;
            d_main_appointmentID_tbx.Enabled = false;
            d_main_appoint_b.Enabled = false;
            d_main_view_b.Enabled = false;
        }

        private void d_main_appointment_date_dtp_ValueChanged(object sender, EventArgs e)
        {

        }

        private void d_main_patient_name_tbx_TextChanged(object sender, EventArgs e)
        {

        }

        private void d_main_appointmentID_combo_TextChanged(object sender, EventArgs e)
        {

        }

        private void d_main_caseID_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            d_main_appointmentID_tbx.Clear();
            d_main_appointmentID_tbx.Clear();
            
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select PatientName from Patient p, InstructCase ic where ic.Patient_idPatient=p.idPatient and idCase =" + Convert.ToInt32(d_main_caseID_combo.Text);
            d_main_patient_name_tbx.Text = cmd.ExecuteScalar().ToString();
            try
            {
                cmd.CommandText = "select idAppointment from Appointment where InstructCase_idCase = " + Convert.ToInt32(d_main_caseID_combo.Text);
                d_main_appointmentID_tbx.Text = cmd.ExecuteScalar().ToString();
                cmd.CommandText = "select AppDatenTime from Appointment where InstructCase_idCase = " + Convert.ToInt32(d_main_caseID_combo.Text);
                d_main_appointment_date_dtp.Text = cmd.ExecuteScalar().ToString();
            }
            catch
            {

            }
            d_main_appoint_b.Enabled = true;
            d_main_view_b.Enabled = true;
        }

        private void d_main_editinfo_b_Click(object sender, EventArgs e)
        {
            d_main_doctor_name_tbx.Enabled = true;
            d_main_number_tbx.Enabled = true;
            d_main_email_tbx.Enabled = true;
            d_main_doctor_address_tbx.Enabled = true;
            d_main_Qualification_tbx.Enabled = true;
            d_main_specialization_tbx.Enabled = true;
            d_main_gender_m_rb.Enabled = true;
            d_main_gender_f_rb.Enabled = true;
            d_main_gender_o_rb.Enabled = true;
        }

        private void d_main_general_save_b_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            char gender;
            if (d_main_gender_m_rb.Checked)
            {
                gender = 'm';
            }
            else if (d_main_gender_f_rb.Checked)
            {
                gender = 'f';
            }
            else
            {
                gender = 'o';
            }
            cmd.CommandText = "update Doctor set doctorname = '" + d_main_doctor_name_tbx.Text + "', contactno = " + (d_main_number_tbx.Text) + ", emailID = '" + d_main_email_tbx.Text +
                "', address = '" + d_main_doctor_address_tbx.Text + "', qualification = '" + d_main_Qualification_tbx.Text + "', specialization = '" + d_main_specialization_tbx.Text + "', gender = '" +
                gender + "' where idDoctor = " + doctorID;
            cmd.ExecuteScalar();
            d_main_doctor_name_tbx.Enabled = false;
            d_main_number_tbx.Enabled = false;
            d_main_email_tbx.Enabled = false;
            d_main_doctor_address_tbx.Enabled = false;
            d_main_Qualification_tbx.Enabled = false;
            d_main_specialization_tbx.Enabled = false;
            d_main_gender_m_rb.Enabled = false;
            d_main_gender_f_rb.Enabled = false;
            d_main_gender_o_rb.Enabled = false;
        }

        private void d_main_find_b_Click(object sender, EventArgs e)
        {
            
            d_main_caseID_combo.Items.Clear();
            string appointed = " ";
            string unappointed = " ";
            string confirmed = " ";
            string rejected = " ";
            if (d_main_appointed_cbx.Checked)
            {
                appointed = "appointed";
            }
            if (d_main_unappointed_cbx.Checked)
            {
                unappointed = "unappointed";
            }
            if (d_main_confirmed_cbx.Checked)
            {
                confirmed = "confirmed";
            }
            if (d_main_rejected_cbx.Checked)
            {
                rejected = "rejected";
            }
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select idCase from InstructCase where AppointmentStatus = '" + appointed + "' or AppointmentStatus = '" + unappointed + "' union select InstructCase_idCase from Appointment " +
                "where ConfirmationStatus = '" + confirmed + "' or ConfirmationStatus = '" + rejected + "'";
            SqlDataReader sqlReader = cmd.ExecuteReader();
            while (sqlReader.Read())
            {
                d_main_caseID_combo.Items.Add(sqlReader["idCase"].ToString());
            }
            sqlReader.Close();
        }

        private void d_main_view_b_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                d_main_page_viewdetails viewDetails = new d_main_page_viewdetails();
                viewDetails.caseID = Convert.ToInt32(d_main_caseID_combo.Text);
                viewDetails.Closed += (s, args) => this.Show();
                viewDetails.Show();
            }
            catch
            {
                
            }
        }

        private void d_main_close_b_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void d_main_appoint_b_Click(object sender, EventArgs e)
        {
            if (d_main_caseID_combo.Text.Length > 0 && d_main_clinic_combo.Text.Length > 0)// d_main_appointment_date_dtp.Text.Length > 0)
            {
                try
                {
                    string selectDateAsString = d_main_appointment_date_dtp.Value.ToString("yyyy-MM-dd");
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con1;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "select idClinic from clinic where clinicname = '" + d_main_clinic_combo.Text + "'";
                    string idClinic = cmd.ExecuteScalar().ToString();
                    cmd.CommandText = "insert into Appointment(InstructCase_idCase, Clinic_idClinic, Doctor_idDoctor, AppDatenTime, ConfirmationStatus) values(" +
                        Convert.ToInt32(d_main_caseID_combo.Text) + "," + Convert.ToInt32(idClinic) + "," + doctorID + ",'" + selectDateAsString + "', 'pending')";
                    cmd.ExecuteScalar();
                    cmd.CommandText = "update instructcase set appointmentstatus = 'appointed' where idCase = '" +  d_main_caseID_combo.Text + " '";
                    cmd.ExecuteScalar();
                    MessageBox.Show("Appointment Created Successfully!");
                }
                catch
                {
                    MessageBox.Show("Appointment Creation Failed!");
                }
            }
            else
            {
                MessageBox.Show("Appointment Creation Failed");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void d_main_clinic_name_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select idclinic from clinic where clinicname = '" + d_main_clinic_name_combo.Text + "'";
            d_main_clinicID_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select address from clinic where clinicname = '" + d_main_clinic_name_combo.Text + "'";
            d_main_clinic_address_tbx.Text = cmd.ExecuteScalar().ToString();
        }

        private void registerasdoctor_clinic1_time1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void d_main_weekday_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select count(WeekDay) from Clinic_has_Doctor where WeekDay = '" + d_main_weekday_combo.Text + "' and doctor_iddoctor = '" + doctorID + "' and clinic_idclinic = '" + d_main_clinicID_tbx.Text + "'";
            string count = cmd.ExecuteScalar().ToString();
            if (count == "0")
            {
                d_main_nositting_cbx.Checked = true;
            }
            else
            {
                d_main_nositting_cbx.Checked = false;
                cmd.CommandText = "select begintime from Clinic_has_Doctor where WeekDay = '" + d_main_weekday_combo.Text + "' and doctor_iddoctor = '" + doctorID + "' and clinic_idclinic = '" + d_main_clinicID_tbx.Text + "'";
                registerasdoctor_clinic1_time1.Text = cmd.ExecuteScalar().ToString();
                cmd.CommandText = "select endtime from Clinic_has_Doctor where WeekDay = '" + d_main_weekday_combo.Text + "' and doctor_iddoctor = '" + doctorID + "' and clinic_idclinic = '" + d_main_clinicID_tbx.Text + "'";
                registerasdoctor_clinic1_time2.Text = cmd.ExecuteScalar().ToString();
            }
            registerasdoctor_clinic1_time1.Enabled = false;
            registerasdoctor_clinic1_time2.Enabled = false;
            d_main_nositting_cbx.Enabled = false;
        }

        private void d_main_edit_clinic_b_Click(object sender, EventArgs e)
        {
            if (d_main_clinic_name_combo.Text.Length>0 && d_main_weekday_combo.Text.Length>0)
            {
                //registerasdoctor_clinic1_time1.Enabled = true;
                //registerasdoctor_clinic1_time2.Enabled = true;
                d_main_nositting_cbx.Enabled = true;
            }
            else
            {
                MessageBox.Show("Select the clinic and the weekday!");
            }
        }

        private void d_main_nositting_cbx_CheckedChanged(object sender, EventArgs e)
        {
            registerasdoctor_clinic1_time1.Enabled = (!d_main_nositting_cbx.Checked);
            registerasdoctor_clinic1_time2.Enabled = (!d_main_nositting_cbx.Checked);
        }

        private void d_main_clinic_save_b_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete clinic_has_doctor where WeekDay = '" + d_main_weekday_combo.Text + "' and doctor_iddoctor = " + doctorID + " and clinic_idclinic = " + Convert.ToInt32(d_main_clinicID_tbx.Text);
            cmd.ExecuteScalar();
            if (!d_main_nositting_cbx.Checked)
            {
                cmd.CommandText = "insert into Clinic_has_Doctor(Clinic_idClinic,Doctor_idDoctor,WeekDay,beginTime,endTime) values (" + Convert.ToInt32(d_main_clinicID_tbx.Text) + "," + doctorID + ",'" + d_main_weekday_combo.Text + "','" + registerasdoctor_clinic1_time1.Text + "','" + registerasdoctor_clinic1_time2.Text + "')";
                cmd.ExecuteScalar();
            }
            MessageBox.Show("Modified successfully!");
        }

        private void schedulegrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Appointments_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void registerasdoctor_clinic1_time2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void d_main_clinic_combo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void doctortimings_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
