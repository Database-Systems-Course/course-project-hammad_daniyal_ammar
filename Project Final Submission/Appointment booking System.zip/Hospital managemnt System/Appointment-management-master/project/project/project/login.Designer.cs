﻿namespace project
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.login_doctor_rb = new System.Windows.Forms.RadioButton();
            this.login_patient_rb = new System.Windows.Forms.RadioButton();
            this.login_username_tbx = new System.Windows.Forms.MaskedTextBox();
            this.login_password_tbx = new System.Windows.Forms.MaskedTextBox();
            this.login_username_label = new System.Windows.Forms.Label();
            this.login_password_label = new System.Windows.Forms.Label();
            this.login_signin_b = new System.Windows.Forms.Button();
            this.login_register_b = new System.Windows.Forms.Button();
            this.login_type_gbx = new System.Windows.Forms.GroupBox();
            this.login_close_b = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.login_type_gbx.SuspendLayout();
            this.SuspendLayout();
            // 
            // login_doctor_rb
            // 
            this.login_doctor_rb.AutoSize = true;
            this.login_doctor_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_doctor_rb.Location = new System.Drawing.Point(21, 23);
            this.login_doctor_rb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_doctor_rb.Name = "login_doctor_rb";
            this.login_doctor_rb.Size = new System.Drawing.Size(75, 22);
            this.login_doctor_rb.TabIndex = 0;
            this.login_doctor_rb.TabStop = true;
            this.login_doctor_rb.Text = "Doctor";
            this.login_doctor_rb.UseVisualStyleBackColor = true;
            this.login_doctor_rb.CheckedChanged += new System.EventHandler(this.login_doctor_rb_CheckedChanged);
            // 
            // login_patient_rb
            // 
            this.login_patient_rb.AutoSize = true;
            this.login_patient_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_patient_rb.Location = new System.Drawing.Point(21, 68);
            this.login_patient_rb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_patient_rb.Name = "login_patient_rb";
            this.login_patient_rb.Size = new System.Drawing.Size(74, 22);
            this.login_patient_rb.TabIndex = 1;
            this.login_patient_rb.TabStop = true;
            this.login_patient_rb.Text = "Patient";
            this.login_patient_rb.UseVisualStyleBackColor = true;
            // 
            // login_username_tbx
            // 
            this.login_username_tbx.Location = new System.Drawing.Point(252, 42);
            this.login_username_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_username_tbx.Name = "login_username_tbx";
            this.login_username_tbx.Size = new System.Drawing.Size(293, 22);
            this.login_username_tbx.TabIndex = 2;
            this.login_username_tbx.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.login_username_tbx_MaskInputRejected);
            // 
            // login_password_tbx
            // 
            this.login_password_tbx.Location = new System.Drawing.Point(252, 92);
            this.login_password_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_password_tbx.Name = "login_password_tbx";
            this.login_password_tbx.PasswordChar = '*';
            this.login_password_tbx.Size = new System.Drawing.Size(293, 22);
            this.login_password_tbx.TabIndex = 3;
            this.login_password_tbx.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.login_password_tbx_MaskInputRejected);
            // 
            // login_username_label
            // 
            this.login_username_label.AutoSize = true;
            this.login_username_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_username_label.Location = new System.Drawing.Point(145, 43);
            this.login_username_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.login_username_label.Name = "login_username_label";
            this.login_username_label.Size = new System.Drawing.Size(81, 18);
            this.login_username_label.TabIndex = 4;
            this.login_username_label.Text = "Username:";
            this.login_username_label.Click += new System.EventHandler(this.login_username_label_Click);
            // 
            // login_password_label
            // 
            this.login_password_label.AutoSize = true;
            this.login_password_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_password_label.Location = new System.Drawing.Point(145, 94);
            this.login_password_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.login_password_label.Name = "login_password_label";
            this.login_password_label.Size = new System.Drawing.Size(79, 18);
            this.login_password_label.TabIndex = 5;
            this.login_password_label.Text = "Password:";
            // 
            // login_signin_b
            // 
            this.login_signin_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.login_signin_b.Location = new System.Drawing.Point(573, 64);
            this.login_signin_b.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_signin_b.Name = "login_signin_b";
            this.login_signin_b.Size = new System.Drawing.Size(100, 28);
            this.login_signin_b.TabIndex = 7;
            this.login_signin_b.Text = "Sign in!";
            this.login_signin_b.UseVisualStyleBackColor = true;
            this.login_signin_b.Click += new System.EventHandler(this.login_signin_b_Click);
            // 
            // login_register_b
            // 
            this.login_register_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_register_b.Location = new System.Drawing.Point(573, 21);
            this.login_register_b.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_register_b.Name = "login_register_b";
            this.login_register_b.Size = new System.Drawing.Size(100, 28);
            this.login_register_b.TabIndex = 8;
            this.login_register_b.Text = "Register";
            this.login_register_b.UseVisualStyleBackColor = true;
            this.login_register_b.Click += new System.EventHandler(this.login_register_button_Click);
            // 
            // login_type_gbx
            // 
            this.login_type_gbx.Controls.Add(this.login_doctor_rb);
            this.login_type_gbx.Controls.Add(this.login_patient_rb);
            this.login_type_gbx.Location = new System.Drawing.Point(16, 21);
            this.login_type_gbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_type_gbx.Name = "login_type_gbx";
            this.login_type_gbx.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_type_gbx.Size = new System.Drawing.Size(121, 118);
            this.login_type_gbx.TabIndex = 9;
            this.login_type_gbx.TabStop = false;
            // 
            // login_close_b
            // 
            this.login_close_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.login_close_b.Location = new System.Drawing.Point(573, 102);
            this.login_close_b.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.login_close_b.Name = "login_close_b";
            this.login_close_b.Size = new System.Drawing.Size(100, 28);
            this.login_close_b.TabIndex = 10;
            this.login_close_b.Text = "Close";
            this.login_close_b.UseVisualStyleBackColor = true;
            this.login_close_b.Click += new System.EventHandler(this.login_close_b_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(573, 138);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 46);
            this.button1.TabIndex = 11;
            this.button1.Text = "Delete Account";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 198);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.login_close_b);
            this.Controls.Add(this.login_type_gbx);
            this.Controls.Add(this.login_register_b);
            this.Controls.Add(this.login_signin_b);
            this.Controls.Add(this.login_password_label);
            this.Controls.Add(this.login_username_label);
            this.Controls.Add(this.login_password_tbx);
            this.Controls.Add(this.login_username_tbx);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "login";
            this.Text = "login";
            this.Load += new System.EventHandler(this.login_Load);
            this.login_type_gbx.ResumeLayout(false);
            this.login_type_gbx.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton login_doctor_rb;
        private System.Windows.Forms.RadioButton login_patient_rb;
        private System.Windows.Forms.MaskedTextBox login_username_tbx;
        private System.Windows.Forms.MaskedTextBox login_password_tbx;
        private System.Windows.Forms.Label login_username_label;
        private System.Windows.Forms.Label login_password_label;
        private System.Windows.Forms.Button login_signin_b;
        private System.Windows.Forms.Button login_register_b;
        private System.Windows.Forms.GroupBox login_type_gbx;
        private System.Windows.Forms.Button login_close_b;
        private System.Windows.Forms.Button button1;
    }
}

