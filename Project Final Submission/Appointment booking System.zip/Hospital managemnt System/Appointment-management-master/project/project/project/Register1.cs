﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project
{
    public partial class Register1 : Form
    {
        SqlConnection con1;
        public Register1()
        {
            InitializeComponent();
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void register1_proceed_b_Click(object sender, EventArgs e)
        {
            if (register1_password_tbx.Text == register1_retype_tbx.Text)
            {
                if (register1_username_tbx.TextLength >= 4 && register1_password_tbx.TextLength >= 6)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "select count(Username) from Login where Username='" + register1_username_tbx.Text + "'";
                    cmd.Connection = con1;
                    cmd.CommandType = CommandType.Text;
                    string id = cmd.ExecuteScalar().ToString();
                    if (id == "0")
                    {
                        this.Hide();
                        Access access = new Access();
                        access.username = register1_username_tbx.Text;
                        access.password = register1_password_tbx.Text;
                        Register2_Specialization_label form2 = new Register2_Specialization_label();
                        form2.setAccess(access);
                        form2.Closed += (s, args) => this.Close();
                        form2.Show();
                    }
                    else
                    {
                        MessageBox.Show("Username in use");
                    }
                }
                else
                {
                    MessageBox.Show("Enter valid username and password");
                }
            }
            else
            {
                MessageBox.Show("Passwords do not match!");
            }
        }

        private void Register1_Load(object sender, EventArgs e)
        {
            //con1 = new SqlConnection("Data Source =.; Initial Catalog = PMS; User ID = sa; Password=Habib123##"); 
            con1 = new SqlConnection(@"Data Source=DESKTOP-PGBON6F;Initial Catalog=AppointmentProj;Integrated Security=SSPI;User ID=DESKTOP-PGBON6F\HP;Password=");
            //public SqlCommand cmd = new SqlCommand(); 
            con1.Open();
        }

        private void register1_username_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
    public class Access
    {
        public string username;
        public string password;
        public Access()
        {
 
        }
    }
}
