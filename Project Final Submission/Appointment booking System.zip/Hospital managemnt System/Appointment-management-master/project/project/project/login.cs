﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace project
{
    public partial class login : Form
    {
        SqlConnection con1;

        public login()
        {
            InitializeComponent();
        }

        private void login_register_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Register1 form1 = new Register1();
            form1.Closed += (s, args) => this.Show();
            form1.Show();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void login_signin_b_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            if (login_doctor_rb.Checked)
            {
                cmd.CommandText = "select username,loginpassword " +
                    "from Login where username = '" + login_username_tbx.Text + "'and loginpassword='" + login_password_tbx.Text + "' and doctor_iddoctor is not null ";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.Text;
                try
                {
                    string id = cmd.ExecuteScalar().ToString();
                    this.Hide();
                    d_main_page form1 = new d_main_page();
                    cmd.CommandText = "select doctor_iddoctor " +
                    "from Login where username = '" + login_username_tbx.Text + "'and loginpassword='" + login_password_tbx.Text + "' and doctor_iddoctor is not null ";
                    form1.doctorID = Convert.ToInt32(cmd.ExecuteScalar());
                    form1.Closed += (s, args) => this.Show();
                    form1.Show();          
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid User Name/Password");
                }
            }
            else if (login_patient_rb.Checked)
            {
                cmd.CommandText = "select username,loginpassword " +
                    "from Login where username = '" + login_username_tbx.Text + "'and loginpassword='" + login_password_tbx.Text + "' and patient_idpatient is not null ";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.Text;
                try
                {
                    string id = cmd.ExecuteScalar().ToString();
                    this.Hide();
                    p_main_page form1 = new p_main_page();
                    cmd.CommandText = "select patient_idpatient " +
                    "from Login where username = '" + login_username_tbx.Text + "'and loginpassword='" + login_password_tbx.Text + "' and patient_idpatient is not null ";
                    form1.patientID = Convert.ToInt32(cmd.ExecuteScalar());
                    form1.Closed += (s, args) => this.Show();
                    form1.Show();                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid User Name/Password");
                }
            }
           
        }

        private void login_doctor_rb_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void login_Load(object sender, EventArgs e)
        {
            //con1 = new SqlConnection("Data Source =.; Initial Catalog = PMS; User ID = sa; Password=Habib123##"); 
            con1 = new SqlConnection(@"Data Source=DESKTOP-PGBON6F;Initial Catalog=AppointmentProj;Integrated Security=SSPI;User ID=DESKTOP-PGBON6F\HP;Password=");
            //public SqlCommand cmd = new SqlCommand(); 
            con1.Open();
        }

        private void login_username_label_Click(object sender, EventArgs e)
        {

        }

        private void login_close_b_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void login_username_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form1 form1 = new Form1();
            form1.Closed += (s, args) => this.Show();
            form1.Show();
        }

        private void login_password_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
