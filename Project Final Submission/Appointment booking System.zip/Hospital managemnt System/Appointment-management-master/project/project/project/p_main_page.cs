﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project
{
    public partial class p_main_page : Form
    {
        SqlConnection con1;
        public int patientID = 0;
        public p_main_page()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void patienthome_instruct_b_Click(object sender, EventArgs e)
        {
            this.Hide();
            Instruct_case form6 = new Instruct_case();
            form6.patientID = patientID;
            form6.Closed += (s, args) => this.Show();
            form6.Show();
        }

        private void p_main_page_Load(object sender, EventArgs e)
        {
            //con1 = new SqlConnection("Data Source =.; Initial Catalog = PMS; User ID = sa; Password=Habib123##"); 
            con1 = new SqlConnection(@"Data Source=DESKTOP-PGBON6F;Initial Catalog=AppointmentProj;Integrated Security=SSPI;User ID=DESKTOP-PGBON6F\HP;Password=");
            //public SqlCommand cmd = new SqlCommand(); 
            con1.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select patientname from patient where idpatient = " + patientID;
            d_main_patient_name_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select contactno from patient where idpatient = " + patientID;
            d_main_number_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select emailID from patient where idpatient = " + patientID;
            d_main_email_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select address from patient where idpatient = " + patientID;
            d_main_doctor_address_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select emergencycontactname from patient where idpatient = " + patientID;
            p_emergencyname_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select emergencycontactno from patient where idpatient = " + patientID;
            p_emergencynum_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select gender from patient where idPatient = " + patientID;
            cmd.CommandText = "select emergencycontact from patient where idpatient = " + patientID;
            p_emergencyname_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select emergencynumber from patient where idpatient = " + patientID;
            p_emergencynum_tbx.Text = cmd.ExecuteScalar().ToString();



            string gender = cmd.ExecuteScalar().ToString();
            if (gender == "m")
            {
                d_main_gender_m_rb.Checked = true;
            }
            else if (gender == "f")
            {
                d_main_gender_f_rb.Checked = true;
            }
            else if (gender == "o")
            {
                d_main_gender_o_rb.Checked = true;
            }
            d_main_caseID_combo.Items.Clear();
            cmd.CommandText = "select idCase from instructcase where patient_idpatient =" + patientID;
            SqlDataReader sqlReader = cmd.ExecuteReader();
            while (sqlReader.Read())
            {
                d_main_caseID_combo.Items.Add(sqlReader["idCase"].ToString());
            }
            sqlReader.Close();
            d_main_patient_name_tbx.Enabled = false;
            d_main_number_tbx.Enabled = false;
            d_main_email_tbx.Enabled = false;
            d_main_doctor_address_tbx.Enabled = false;
            p_emergencyname_tbx.Enabled = false;
            p_emergencynum_tbx.Enabled = false;
            d_main_gender_m_rb.Enabled = false;
            d_main_gender_f_rb.Enabled = false;
            d_main_gender_o_rb.Enabled = false;
            d_main_doctor_name_tbx.Enabled = false;
            d_main_appointmentID_tbx.Enabled = false;
            d_main_appointment_date_dtp.Enabled = false;
            dmain_appStatus_tbx.Enabled = false;
            IC_casedetails_tbx.Enabled = false;
        }

        private void d_main_editinfo_b_Click(object sender, EventArgs e)
        {
            d_main_patient_name_tbx.Enabled = true;
            d_main_number_tbx.Enabled = true;
            d_main_email_tbx.Enabled = true;
            d_main_doctor_address_tbx.Enabled = true;
            p_emergencyname_tbx.Enabled = true;
            p_emergencynum_tbx.Enabled = true;
            d_main_gender_m_rb.Enabled = true;
            d_main_gender_f_rb.Enabled = true;
            d_main_gender_o_rb.Enabled = true;
        }

        private void d_main_general_save_b_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            char gender;
            if (d_main_gender_m_rb.Checked)
            {
                gender = 'm';
            }
            else if (d_main_gender_f_rb.Checked)
            {
                gender = 'f';
            }
            else
            {
                gender = 'o';
            }
            cmd.CommandText = "update Patient set patientname = '" + d_main_patient_name_tbx.Text + "', contactno = " + Convert.ToInt32(d_main_number_tbx.Text) + ", emailID = '" + d_main_email_tbx.Text +
                "', address = '" + d_main_doctor_address_tbx.Text + "', emergencycontactname = '" + p_emergencyname_tbx.Text + "', emergencynumber = '" + p_emergencynum_tbx.Text + "', gender = '" +
                gender + "' where idPatient = " + patientID;
            cmd.ExecuteScalar();
            d_main_patient_name_tbx.Enabled = false;
            d_main_number_tbx.Enabled = false;
            d_main_email_tbx.Enabled = false;
            d_main_doctor_address_tbx.Enabled = false;
            p_emergencynum_tbx.Enabled = false;
            p_emergencyname_tbx.Enabled = false;
            d_main_gender_m_rb.Enabled = false;
            d_main_gender_f_rb.Enabled = false;
            d_main_gender_o_rb.Enabled = false;
            p_casetype_tbx.Enabled = false;
            p_specialinstructions_tbx.Enabled = false;
        }

        private void d_main_caseID_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            d_main_confirm_b.Enabled = true;
            d_main_reject_b.Enabled = true;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select idappointment from appointment where instructcase_idcase =" + Convert.ToInt32(d_main_caseID_combo.Text);
            try
            {
                string appIDstr = cmd.ExecuteScalar().ToString();
                int appID = Convert.ToInt32(appIDstr);
                d_main_appointmentID_tbx.Text = appIDstr;
                //select doctorname from appointment a,doctor d where a.doctor_iddoctor=d.iddoctor and idappointment =
                cmd.CommandText = "exec findDoc " + appID;
                d_main_doctor_name_tbx.Text = cmd.ExecuteScalar().ToString();
                cmd.CommandText = "select appdatentime from appointmentView where idappointment = " + appID;
                d_main_appointment_date_dtp.Text = cmd.ExecuteScalar().ToString();
                cmd.CommandText = "select Confirmationstatus from appointmentView where idappointment = " + appID;
                dmain_appStatus_tbx.Text = cmd.ExecuteScalar().ToString();
                if (dmain_appStatus_tbx.Text == "confirmed")
                {
                    d_main_confirm_b.Enabled = false;
                    d_main_reject_b.Enabled = false;
                }
            }
            catch
            {
                cmd.CommandText = "select appointmentstatus from instructcase where idcase = " + Convert.ToInt32(d_main_caseID_combo.Text);
                dmain_appStatus_tbx.Text = cmd.ExecuteScalar().ToString();
                d_main_confirm_b.Enabled = false;
                d_main_reject_b.Enabled = false;
            }
            if (dmain_appStatus_tbx.Text == "rejected")
            {
                dmain_appStatus_tbx.Text = "unappointed";
                d_main_confirm_b.Enabled = false;
                d_main_reject_b.Enabled = false;
            }
            cmd.CommandText = "select casetype from instructcase where idcase = " + Convert.ToInt32(d_main_caseID_combo.Text);
            p_casetype_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select specialinstructions from instructcase where idcase = " + Convert.ToInt32(d_main_caseID_combo.Text);
            p_specialinstructions_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select casedetails from instructcase where idcase = " + Convert.ToInt32(d_main_caseID_combo.Text);
            IC_casedetails_tbx.Text = cmd.ExecuteScalar().ToString();
        }

        private void d_main_confirm_b_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update appointment set confirmationstatus = 'confirmed' where confirmationstatus = 'pending' and instructcase_idCase = " + Convert.ToInt32(d_main_caseID_combo.Text);
            cmd.ExecuteScalar();
            dmain_appStatus_tbx.Text = "confirmed";              
            MessageBox.Show("Appointment Confirmed Successfully!");
        }

        private void d_main_reject_b_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update appointment set confirmationstatus = 'rejected' where confirmationstatus = 'pending' and instructcase_idCase = " + Convert.ToInt32(d_main_caseID_combo.Text);
            cmd.ExecuteScalar();
            MessageBox.Show("Appointment Rejected!");
            cmd.CommandText = "update instructcase set appointmentstatus = 'unappointed' where idCase = " + Convert.ToInt32(d_main_caseID_combo.Text);
            dmain_appStatus_tbx.Text = "rejected";
        }

        private void label44_Click(object sender, EventArgs e)
        {

        }

        private void d_main_appointmentID_tbx_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void p_signout_b_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void p_emergencyname_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void d_main_doctor_address_tbx_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void p_emergencynum_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
