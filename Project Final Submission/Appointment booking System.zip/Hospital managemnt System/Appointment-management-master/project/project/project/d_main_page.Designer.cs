﻿namespace project
{
    partial class d_main_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.d_main_view_b = new System.Windows.Forms.Button();
            this.d_main_unappointed_cbx = new System.Windows.Forms.CheckBox();
            this.d_main_find_b = new System.Windows.Forms.Button();
            this.d_main_appoint_b = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.d_main_appointment_date_dtp = new System.Windows.Forms.DateTimePicker();
            this.d_main_appointmentID_tbx = new System.Windows.Forms.TextBox();
            this.d_main_patient_name_tbx = new System.Windows.Forms.TextBox();
            this.d_main_caseID_combo = new System.Windows.Forms.ComboBox();
            this.d_main_rejected_cbx = new System.Windows.Forms.CheckBox();
            this.d_main_confirmed_cbx = new System.Windows.Forms.CheckBox();
            this.d_main_appointed_cbx = new System.Windows.Forms.CheckBox();
            this.registerasdoctor_clinic1_gbx = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.d_main_editinfo_b = new System.Windows.Forms.Button();
            this.d_main_gender_o_rb = new System.Windows.Forms.RadioButton();
            this.d_main_gender_f_rb = new System.Windows.Forms.RadioButton();
            this.d_main_gender_m_rb = new System.Windows.Forms.RadioButton();
            this.label18 = new System.Windows.Forms.Label();
            this.d_main_general_save_b = new System.Windows.Forms.Button();
            this.d_main_email_tbx = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.d_main_specialization_tbx = new System.Windows.Forms.MaskedTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.d_main_Qualification_tbx = new System.Windows.Forms.MaskedTextBox();
            this.d_main_number_tbx = new System.Windows.Forms.TextBox();
            this.d_main_doctor_address_tbx = new System.Windows.Forms.TextBox();
            this.d_main_doctor_name_tbx = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.register2_address_label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.registerasdoctor_clinic1_time2 = new System.Windows.Forms.DateTimePicker();
            this.registerasdoctor_clinic1_time1 = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.d_main_clinic_combo = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.schedulegrid = new System.Windows.Forms.DataGridView();
            this.Appointments = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.d_main_nositting_cbx = new System.Windows.Forms.CheckBox();
            this.d_main_weekday_combo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.d_main_clinic_save_b = new System.Windows.Forms.Button();
            this.d_main_clinic_name_combo = new System.Windows.Forms.ComboBox();
            this.d_main_edit_clinic_b = new System.Windows.Forms.Button();
            this.d_main_clinic_address_tbx = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.d_main_clinicID_tbx = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.d_main_close_b = new System.Windows.Forms.Button();
            this.doctortimings = new System.Windows.Forms.DataGridView();
            this.registerasdoctor_clinic1_gbx.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.schedulegrid)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.doctortimings)).BeginInit();
            this.SuspendLayout();
            // 
            // d_main_view_b
            // 
            this.d_main_view_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_view_b.Location = new System.Drawing.Point(392, 117);
            this.d_main_view_b.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_view_b.Name = "d_main_view_b";
            this.d_main_view_b.Size = new System.Drawing.Size(121, 31);
            this.d_main_view_b.TabIndex = 70;
            this.d_main_view_b.Text = "View";
            this.d_main_view_b.UseVisualStyleBackColor = true;
            this.d_main_view_b.Click += new System.EventHandler(this.d_main_view_b_Click);
            // 
            // d_main_unappointed_cbx
            // 
            this.d_main_unappointed_cbx.AutoSize = true;
            this.d_main_unappointed_cbx.Location = new System.Drawing.Point(352, 42);
            this.d_main_unappointed_cbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_unappointed_cbx.Name = "d_main_unappointed_cbx";
            this.d_main_unappointed_cbx.Size = new System.Drawing.Size(111, 21);
            this.d_main_unappointed_cbx.TabIndex = 67;
            this.d_main_unappointed_cbx.Text = "Unappointed";
            this.d_main_unappointed_cbx.UseVisualStyleBackColor = true;
            // 
            // d_main_find_b
            // 
            this.d_main_find_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_find_b.Location = new System.Drawing.Point(392, 80);
            this.d_main_find_b.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_find_b.Name = "d_main_find_b";
            this.d_main_find_b.Size = new System.Drawing.Size(121, 31);
            this.d_main_find_b.TabIndex = 66;
            this.d_main_find_b.Text = "Find";
            this.d_main_find_b.UseVisualStyleBackColor = true;
            this.d_main_find_b.Click += new System.EventHandler(this.d_main_find_b_Click);
            // 
            // d_main_appoint_b
            // 
            this.d_main_appoint_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_appoint_b.Location = new System.Drawing.Point(392, 151);
            this.d_main_appoint_b.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_appoint_b.Name = "d_main_appoint_b";
            this.d_main_appoint_b.Size = new System.Drawing.Size(121, 31);
            this.d_main_appoint_b.TabIndex = 55;
            this.d_main_appoint_b.Text = "APPOINT";
            this.d_main_appoint_b.UseVisualStyleBackColor = true;
            this.d_main_appoint_b.Click += new System.EventHandler(this.d_main_appoint_b_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(4, 187);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(125, 17);
            this.label40.TabIndex = 63;
            this.label40.Text = "Appointment Date:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(4, 155);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(97, 17);
            this.label42.TabIndex = 60;
            this.label42.Text = "Patient Name:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(4, 84);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(61, 17);
            this.label43.TabIndex = 59;
            this.label43.Text = "Case ID:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(4, 121);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(108, 17);
            this.label44.TabIndex = 58;
            this.label44.Text = "Appointment ID:";
            // 
            // d_main_appointment_date_dtp
            // 
            this.d_main_appointment_date_dtp.CustomFormat = "yyyy-MM-dd hh:mm";
            this.d_main_appointment_date_dtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.d_main_appointment_date_dtp.Location = new System.Drawing.Point(132, 185);
            this.d_main_appointment_date_dtp.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_appointment_date_dtp.Name = "d_main_appointment_date_dtp";
            this.d_main_appointment_date_dtp.Size = new System.Drawing.Size(247, 22);
            this.d_main_appointment_date_dtp.TabIndex = 57;
            this.d_main_appointment_date_dtp.ValueChanged += new System.EventHandler(this.d_main_appointment_date_dtp_ValueChanged);
            // 
            // d_main_appointmentID_tbx
            // 
            this.d_main_appointmentID_tbx.Location = new System.Drawing.Point(132, 117);
            this.d_main_appointmentID_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_appointmentID_tbx.Name = "d_main_appointmentID_tbx";
            this.d_main_appointmentID_tbx.Size = new System.Drawing.Size(247, 22);
            this.d_main_appointmentID_tbx.TabIndex = 54;
            this.d_main_appointmentID_tbx.TextChanged += new System.EventHandler(this.d_main_appointmentID_combo_TextChanged);
            // 
            // d_main_patient_name_tbx
            // 
            this.d_main_patient_name_tbx.Location = new System.Drawing.Point(132, 151);
            this.d_main_patient_name_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_patient_name_tbx.Name = "d_main_patient_name_tbx";
            this.d_main_patient_name_tbx.Size = new System.Drawing.Size(247, 22);
            this.d_main_patient_name_tbx.TabIndex = 53;
            this.d_main_patient_name_tbx.TextChanged += new System.EventHandler(this.d_main_patient_name_tbx_TextChanged);
            // 
            // d_main_caseID_combo
            // 
            this.d_main_caseID_combo.FormattingEnabled = true;
            this.d_main_caseID_combo.Location = new System.Drawing.Point(132, 80);
            this.d_main_caseID_combo.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_caseID_combo.Name = "d_main_caseID_combo";
            this.d_main_caseID_combo.Size = new System.Drawing.Size(247, 24);
            this.d_main_caseID_combo.TabIndex = 52;
            this.d_main_caseID_combo.SelectedIndexChanged += new System.EventHandler(this.d_main_caseID_combo_SelectedIndexChanged);
            // 
            // d_main_rejected_cbx
            // 
            this.d_main_rejected_cbx.AutoSize = true;
            this.d_main_rejected_cbx.Location = new System.Drawing.Point(248, 42);
            this.d_main_rejected_cbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_rejected_cbx.Name = "d_main_rejected_cbx";
            this.d_main_rejected_cbx.Size = new System.Drawing.Size(86, 21);
            this.d_main_rejected_cbx.TabIndex = 8;
            this.d_main_rejected_cbx.Text = "Rejected";
            this.d_main_rejected_cbx.UseVisualStyleBackColor = true;
            // 
            // d_main_confirmed_cbx
            // 
            this.d_main_confirmed_cbx.AutoSize = true;
            this.d_main_confirmed_cbx.Location = new System.Drawing.Point(128, 42);
            this.d_main_confirmed_cbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_confirmed_cbx.Name = "d_main_confirmed_cbx";
            this.d_main_confirmed_cbx.Size = new System.Drawing.Size(94, 21);
            this.d_main_confirmed_cbx.TabIndex = 7;
            this.d_main_confirmed_cbx.Text = "Confirmed";
            this.d_main_confirmed_cbx.UseVisualStyleBackColor = true;
            // 
            // d_main_appointed_cbx
            // 
            this.d_main_appointed_cbx.AutoSize = true;
            this.d_main_appointed_cbx.Location = new System.Drawing.Point(8, 42);
            this.d_main_appointed_cbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_appointed_cbx.Name = "d_main_appointed_cbx";
            this.d_main_appointed_cbx.Size = new System.Drawing.Size(94, 21);
            this.d_main_appointed_cbx.TabIndex = 6;
            this.d_main_appointed_cbx.Text = "Appointed";
            this.d_main_appointed_cbx.UseVisualStyleBackColor = true;
            // 
            // registerasdoctor_clinic1_gbx
            // 
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label3);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_editinfo_b);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_gender_o_rb);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_gender_f_rb);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_gender_m_rb);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label18);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_general_save_b);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_email_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label16);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_specialization_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label21);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label19);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_Qualification_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_number_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_doctor_address_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_doctor_name_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label17);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.register2_address_label);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label4);
            this.registerasdoctor_clinic1_gbx.Location = new System.Drawing.Point(16, 15);
            this.registerasdoctor_clinic1_gbx.Margin = new System.Windows.Forms.Padding(4);
            this.registerasdoctor_clinic1_gbx.Name = "registerasdoctor_clinic1_gbx";
            this.registerasdoctor_clinic1_gbx.Padding = new System.Windows.Forms.Padding(4);
            this.registerasdoctor_clinic1_gbx.Size = new System.Drawing.Size(361, 292);
            this.registerasdoctor_clinic1_gbx.TabIndex = 23;
            this.registerasdoctor_clinic1_gbx.TabStop = false;
            this.registerasdoctor_clinic1_gbx.Text = "General";
            this.registerasdoctor_clinic1_gbx.Enter += new System.EventHandler(this.registerasdoctor_clinic1_gbx_Enter);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 17);
            this.label3.TabIndex = 79;
            this.label3.Text = "03";
            // 
            // d_main_editinfo_b
            // 
            this.d_main_editinfo_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_editinfo_b.Location = new System.Drawing.Point(132, 245);
            this.d_main_editinfo_b.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_editinfo_b.Name = "d_main_editinfo_b";
            this.d_main_editinfo_b.Size = new System.Drawing.Size(205, 28);
            this.d_main_editinfo_b.TabIndex = 78;
            this.d_main_editinfo_b.Text = "Edit Information";
            this.d_main_editinfo_b.UseVisualStyleBackColor = true;
            this.d_main_editinfo_b.Click += new System.EventHandler(this.d_main_editinfo_b_Click);
            // 
            // d_main_gender_o_rb
            // 
            this.d_main_gender_o_rb.AutoSize = true;
            this.d_main_gender_o_rb.Location = new System.Drawing.Point(272, 87);
            this.d_main_gender_o_rb.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_gender_o_rb.Name = "d_main_gender_o_rb";
            this.d_main_gender_o_rb.Size = new System.Drawing.Size(62, 21);
            this.d_main_gender_o_rb.TabIndex = 77;
            this.d_main_gender_o_rb.TabStop = true;
            this.d_main_gender_o_rb.Text = "other";
            this.d_main_gender_o_rb.UseVisualStyleBackColor = true;
            // 
            // d_main_gender_f_rb
            // 
            this.d_main_gender_f_rb.AutoSize = true;
            this.d_main_gender_f_rb.Location = new System.Drawing.Point(205, 87);
            this.d_main_gender_f_rb.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_gender_f_rb.Name = "d_main_gender_f_rb";
            this.d_main_gender_f_rb.Size = new System.Drawing.Size(71, 21);
            this.d_main_gender_f_rb.TabIndex = 76;
            this.d_main_gender_f_rb.TabStop = true;
            this.d_main_gender_f_rb.Text = "female";
            this.d_main_gender_f_rb.UseVisualStyleBackColor = true;
            // 
            // d_main_gender_m_rb
            // 
            this.d_main_gender_m_rb.AutoSize = true;
            this.d_main_gender_m_rb.Location = new System.Drawing.Point(132, 87);
            this.d_main_gender_m_rb.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_gender_m_rb.Name = "d_main_gender_m_rb";
            this.d_main_gender_m_rb.Size = new System.Drawing.Size(59, 21);
            this.d_main_gender_m_rb.TabIndex = 46;
            this.d_main_gender_m_rb.TabStop = true;
            this.d_main_gender_m_rb.Text = "male";
            this.d_main_gender_m_rb.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(8, 87);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 18);
            this.label18.TabIndex = 75;
            this.label18.Text = "Gender:";
            // 
            // d_main_general_save_b
            // 
            this.d_main_general_save_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_general_save_b.Location = new System.Drawing.Point(3, 246);
            this.d_main_general_save_b.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_general_save_b.Name = "d_main_general_save_b";
            this.d_main_general_save_b.Size = new System.Drawing.Size(121, 28);
            this.d_main_general_save_b.TabIndex = 74;
            this.d_main_general_save_b.Text = "Save";
            this.d_main_general_save_b.UseVisualStyleBackColor = true;
            this.d_main_general_save_b.Click += new System.EventHandler(this.d_main_general_save_b_Click);
            // 
            // d_main_email_tbx
            // 
            this.d_main_email_tbx.Location = new System.Drawing.Point(132, 113);
            this.d_main_email_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_email_tbx.Name = "d_main_email_tbx";
            this.d_main_email_tbx.Size = new System.Drawing.Size(208, 22);
            this.d_main_email_tbx.TabIndex = 46;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(8, 116);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 18);
            this.label16.TabIndex = 45;
            this.label16.Text = "Email:";
            // 
            // d_main_specialization_tbx
            // 
            this.d_main_specialization_tbx.Location = new System.Drawing.Point(132, 209);
            this.d_main_specialization_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_specialization_tbx.Name = "d_main_specialization_tbx";
            this.d_main_specialization_tbx.Size = new System.Drawing.Size(208, 22);
            this.d_main_specialization_tbx.TabIndex = 44;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(8, 180);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(93, 18);
            this.label21.TabIndex = 41;
            this.label21.Text = "Qualification:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(8, 212);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(103, 18);
            this.label19.TabIndex = 43;
            this.label19.Text = "Specialization:";
            // 
            // d_main_Qualification_tbx
            // 
            this.d_main_Qualification_tbx.Location = new System.Drawing.Point(132, 177);
            this.d_main_Qualification_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_Qualification_tbx.Name = "d_main_Qualification_tbx";
            this.d_main_Qualification_tbx.Size = new System.Drawing.Size(208, 22);
            this.d_main_Qualification_tbx.TabIndex = 42;
            // 
            // d_main_number_tbx
            // 
            this.d_main_number_tbx.Location = new System.Drawing.Point(143, 58);
            this.d_main_number_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_number_tbx.Name = "d_main_number_tbx";
            this.d_main_number_tbx.Size = new System.Drawing.Size(197, 22);
            this.d_main_number_tbx.TabIndex = 40;
            // 
            // d_main_doctor_address_tbx
            // 
            this.d_main_doctor_address_tbx.Location = new System.Drawing.Point(132, 145);
            this.d_main_doctor_address_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_doctor_address_tbx.Name = "d_main_doctor_address_tbx";
            this.d_main_doctor_address_tbx.Size = new System.Drawing.Size(208, 22);
            this.d_main_doctor_address_tbx.TabIndex = 39;
            // 
            // d_main_doctor_name_tbx
            // 
            this.d_main_doctor_name_tbx.Location = new System.Drawing.Point(132, 21);
            this.d_main_doctor_name_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_doctor_name_tbx.Name = "d_main_doctor_name_tbx";
            this.d_main_doctor_name_tbx.Size = new System.Drawing.Size(208, 22);
            this.d_main_doctor_name_tbx.TabIndex = 38;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(8, 59);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(88, 18);
            this.label17.TabIndex = 37;
            this.label17.Text = "Contact No:";
            // 
            // register2_address_label
            // 
            this.register2_address_label.AutoSize = true;
            this.register2_address_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_address_label.Location = new System.Drawing.Point(8, 148);
            this.register2_address_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.register2_address_label.Name = "register2_address_label";
            this.register2_address_label.Size = new System.Drawing.Size(66, 18);
            this.register2_address_label.TabIndex = 34;
            this.register2_address_label.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 27);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 18);
            this.label4.TabIndex = 11;
            this.label4.Text = "Full Name:";
            // 
            // registerasdoctor_clinic1_time2
            // 
            this.registerasdoctor_clinic1_time2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.registerasdoctor_clinic1_time2.Location = new System.Drawing.Point(132, 218);
            this.registerasdoctor_clinic1_time2.Margin = new System.Windows.Forms.Padding(4);
            this.registerasdoctor_clinic1_time2.Name = "registerasdoctor_clinic1_time2";
            this.registerasdoctor_clinic1_time2.Size = new System.Drawing.Size(247, 22);
            this.registerasdoctor_clinic1_time2.TabIndex = 39;
            this.registerasdoctor_clinic1_time2.ValueChanged += new System.EventHandler(this.registerasdoctor_clinic1_time2_ValueChanged);
            // 
            // registerasdoctor_clinic1_time1
            // 
            this.registerasdoctor_clinic1_time1.CustomFormat = "hh:mm";
            this.registerasdoctor_clinic1_time1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.registerasdoctor_clinic1_time1.Location = new System.Drawing.Point(132, 183);
            this.registerasdoctor_clinic1_time1.Margin = new System.Windows.Forms.Padding(4);
            this.registerasdoctor_clinic1_time1.Name = "registerasdoctor_clinic1_time1";
            this.registerasdoctor_clinic1_time1.Size = new System.Drawing.Size(247, 22);
            this.registerasdoctor_clinic1_time1.TabIndex = 36;
            this.registerasdoctor_clinic1_time1.ValueChanged += new System.EventHandler(this.registerasdoctor_clinic1_time1_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(7, 183);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 18);
            this.label12.TabIndex = 37;
            this.label12.Text = "Opening Time:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(8, 218);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 18);
            this.label13.TabIndex = 38;
            this.label13.Text = "Closing time:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.d_main_clinic_combo);
            this.groupBox1.Controls.Add(this.d_main_appointed_cbx);
            this.groupBox1.Controls.Add(this.d_main_appointment_date_dtp);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.d_main_view_b);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.d_main_appointmentID_tbx);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.d_main_patient_name_tbx);
            this.groupBox1.Controls.Add(this.d_main_unappointed_cbx);
            this.groupBox1.Controls.Add(this.d_main_caseID_combo);
            this.groupBox1.Controls.Add(this.d_main_find_b);
            this.groupBox1.Controls.Add(this.d_main_confirmed_cbx);
            this.groupBox1.Controls.Add(this.d_main_appoint_b);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.d_main_rejected_cbx);
            this.groupBox1.Location = new System.Drawing.Point(385, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(517, 249);
            this.groupBox1.TabIndex = 71;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Case Manager:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 220);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 17);
            this.label2.TabIndex = 72;
            this.label2.Text = "Clinic Name:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // d_main_clinic_combo
            // 
            this.d_main_clinic_combo.FormattingEnabled = true;
            this.d_main_clinic_combo.Items.AddRange(new object[] {
            "Zulfiqar Bhutto Shaheed Hospital",
            "Mareez inn",
            "Habib University Mental Asylum",
            "Get Well Late"});
            this.d_main_clinic_combo.Location = new System.Drawing.Point(132, 217);
            this.d_main_clinic_combo.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_clinic_combo.Name = "d_main_clinic_combo";
            this.d_main_clinic_combo.Size = new System.Drawing.Size(247, 24);
            this.d_main_clinic_combo.TabIndex = 71;
            this.d_main_clinic_combo.SelectedIndexChanged += new System.EventHandler(this.d_main_clinic_combo_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.schedulegrid);
            this.groupBox2.Controls.Add(this.Appointments);
            this.groupBox2.Location = new System.Drawing.Point(15, 314);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(361, 427);
            this.groupBox2.TabIndex = 72;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Schedule:";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // schedulegrid
            // 
            this.schedulegrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.schedulegrid.Location = new System.Drawing.Point(17, 282);
            this.schedulegrid.Margin = new System.Windows.Forms.Padding(4);
            this.schedulegrid.Name = "schedulegrid";
            this.schedulegrid.Size = new System.Drawing.Size(321, 77);
            this.schedulegrid.TabIndex = 1;
            this.schedulegrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.schedulegrid_CellContentClick);
            // 
            // Appointments
            // 
            this.Appointments.FormattingEnabled = true;
            this.Appointments.ItemHeight = 16;
            this.Appointments.Location = new System.Drawing.Point(17, 20);
            this.Appointments.Margin = new System.Windows.Forms.Padding(4);
            this.Appointments.Name = "Appointments";
            this.Appointments.Size = new System.Drawing.Size(335, 212);
            this.Appointments.TabIndex = 0;
            this.Appointments.SelectedIndexChanged += new System.EventHandler(this.Appointments_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.d_main_nositting_cbx);
            this.groupBox3.Controls.Add(this.d_main_weekday_combo);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.d_main_clinic_save_b);
            this.groupBox3.Controls.Add(this.d_main_clinic_name_combo);
            this.groupBox3.Controls.Add(this.registerasdoctor_clinic1_time2);
            this.groupBox3.Controls.Add(this.d_main_edit_clinic_b);
            this.groupBox3.Controls.Add(this.registerasdoctor_clinic1_time1);
            this.groupBox3.Controls.Add(this.d_main_clinic_address_tbx);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.d_main_clinicID_tbx);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Location = new System.Drawing.Point(385, 263);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(517, 258);
            this.groupBox3.TabIndex = 57;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Clinic Manager:";
            // 
            // d_main_nositting_cbx
            // 
            this.d_main_nositting_cbx.AutoSize = true;
            this.d_main_nositting_cbx.Location = new System.Drawing.Point(392, 155);
            this.d_main_nositting_cbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_nositting_cbx.Name = "d_main_nositting_cbx";
            this.d_main_nositting_cbx.Size = new System.Drawing.Size(91, 21);
            this.d_main_nositting_cbx.TabIndex = 73;
            this.d_main_nositting_cbx.Text = "No Sitting";
            this.d_main_nositting_cbx.UseVisualStyleBackColor = true;
            this.d_main_nositting_cbx.CheckedChanged += new System.EventHandler(this.d_main_nositting_cbx_CheckedChanged);
            // 
            // d_main_weekday_combo
            // 
            this.d_main_weekday_combo.FormattingEnabled = true;
            this.d_main_weekday_combo.Location = new System.Drawing.Point(132, 150);
            this.d_main_weekday_combo.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_weekday_combo.Name = "d_main_weekday_combo";
            this.d_main_weekday_combo.Size = new System.Drawing.Size(247, 24);
            this.d_main_weekday_combo.TabIndex = 75;
            this.d_main_weekday_combo.SelectedIndexChanged += new System.EventHandler(this.d_main_weekday_combo_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 151);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 18);
            this.label1.TabIndex = 74;
            this.label1.Text = "Weekday:";
            // 
            // d_main_clinic_save_b
            // 
            this.d_main_clinic_save_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_clinic_save_b.Location = new System.Drawing.Point(364, 82);
            this.d_main_clinic_save_b.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_clinic_save_b.Name = "d_main_clinic_save_b";
            this.d_main_clinic_save_b.Size = new System.Drawing.Size(121, 42);
            this.d_main_clinic_save_b.TabIndex = 73;
            this.d_main_clinic_save_b.Text = "Save";
            this.d_main_clinic_save_b.UseVisualStyleBackColor = true;
            this.d_main_clinic_save_b.Click += new System.EventHandler(this.d_main_clinic_save_b_Click);
            // 
            // d_main_clinic_name_combo
            // 
            this.d_main_clinic_name_combo.FormattingEnabled = true;
            this.d_main_clinic_name_combo.Items.AddRange(new object[] {
            "Zulfiqar Bhutto Shaheed Hospital",
            "Mareez inn",
            "Habib University Mental Asylum",
            "Get Well Late"});
            this.d_main_clinic_name_combo.Location = new System.Drawing.Point(132, 27);
            this.d_main_clinic_name_combo.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_clinic_name_combo.Name = "d_main_clinic_name_combo";
            this.d_main_clinic_name_combo.Size = new System.Drawing.Size(219, 24);
            this.d_main_clinic_name_combo.TabIndex = 72;
            this.d_main_clinic_name_combo.SelectedIndexChanged += new System.EventHandler(this.d_main_clinic_name_combo_SelectedIndexChanged);
            // 
            // d_main_edit_clinic_b
            // 
            this.d_main_edit_clinic_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_edit_clinic_b.Location = new System.Drawing.Point(363, 25);
            this.d_main_edit_clinic_b.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_edit_clinic_b.Name = "d_main_edit_clinic_b";
            this.d_main_edit_clinic_b.Size = new System.Drawing.Size(121, 50);
            this.d_main_edit_clinic_b.TabIndex = 70;
            this.d_main_edit_clinic_b.Text = "Edit Clinic";
            this.d_main_edit_clinic_b.UseVisualStyleBackColor = true;
            this.d_main_edit_clinic_b.Click += new System.EventHandler(this.d_main_edit_clinic_b_Click);
            // 
            // d_main_clinic_address_tbx
            // 
            this.d_main_clinic_address_tbx.Location = new System.Drawing.Point(132, 91);
            this.d_main_clinic_address_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_clinic_address_tbx.Name = "d_main_clinic_address_tbx";
            this.d_main_clinic_address_tbx.Size = new System.Drawing.Size(219, 22);
            this.d_main_clinic_address_tbx.TabIndex = 42;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(8, 89);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 18);
            this.label23.TabIndex = 41;
            this.label23.Text = "Address:";
            // 
            // d_main_clinicID_tbx
            // 
            this.d_main_clinicID_tbx.Location = new System.Drawing.Point(132, 59);
            this.d_main_clinicID_tbx.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_clinicID_tbx.Name = "d_main_clinicID_tbx";
            this.d_main_clinicID_tbx.Size = new System.Drawing.Size(219, 22);
            this.d_main_clinicID_tbx.TabIndex = 40;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(8, 57);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(66, 18);
            this.label22.TabIndex = 38;
            this.label22.Text = "Clinic ID:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(8, 25);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(92, 18);
            this.label20.TabIndex = 37;
            this.label20.Text = "Clinic Name:";
            // 
            // d_main_close_b
            // 
            this.d_main_close_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_close_b.Location = new System.Drawing.Point(781, 521);
            this.d_main_close_b.Margin = new System.Windows.Forms.Padding(4);
            this.d_main_close_b.Name = "d_main_close_b";
            this.d_main_close_b.Size = new System.Drawing.Size(121, 28);
            this.d_main_close_b.TabIndex = 74;
            this.d_main_close_b.Text = "Signout";
            this.d_main_close_b.UseVisualStyleBackColor = true;
            this.d_main_close_b.Click += new System.EventHandler(this.d_main_close_b_Click);
            // 
            // doctortimings
            // 
            this.doctortimings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.doctortimings.Location = new System.Drawing.Point(928, 27);
            this.doctortimings.Margin = new System.Windows.Forms.Padding(4);
            this.doctortimings.Name = "doctortimings";
            this.doctortimings.Size = new System.Drawing.Size(589, 714);
            this.doctortimings.TabIndex = 75;
            this.doctortimings.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.doctortimings_CellContentClick);
            // 
            // d_main_page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1533, 756);
            this.Controls.Add(this.doctortimings);
            this.Controls.Add(this.d_main_close_b);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.registerasdoctor_clinic1_gbx);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "d_main_page";
            this.Text = "Home[Doctor]";
            this.Load += new System.EventHandler(this.d_main_page_Load);
            this.registerasdoctor_clinic1_gbx.ResumeLayout(false);
            this.registerasdoctor_clinic1_gbx.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.schedulegrid)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.doctortimings)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.CheckBox d_main_unappointed_cbx;
        private System.Windows.Forms.Button d_main_find_b;
        private System.Windows.Forms.Button d_main_appoint_b;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.DateTimePicker d_main_appointment_date_dtp;
        private System.Windows.Forms.TextBox d_main_appointmentID_tbx;
        private System.Windows.Forms.TextBox d_main_patient_name_tbx;
        private System.Windows.Forms.ComboBox d_main_caseID_combo;
        private System.Windows.Forms.CheckBox d_main_rejected_cbx;
        private System.Windows.Forms.CheckBox d_main_confirmed_cbx;
        private System.Windows.Forms.CheckBox d_main_appointed_cbx;
        private System.Windows.Forms.Button d_main_view_b;
        private System.Windows.Forms.GroupBox registerasdoctor_clinic1_gbx;
        private System.Windows.Forms.TextBox d_main_doctor_name_tbx;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DateTimePicker registerasdoctor_clinic1_time2;
        private System.Windows.Forms.DateTimePicker registerasdoctor_clinic1_time1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label register2_address_label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox d_main_number_tbx;
        private System.Windows.Forms.TextBox d_main_doctor_address_tbx;
        private System.Windows.Forms.MaskedTextBox d_main_specialization_tbx;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.MaskedTextBox d_main_Qualification_tbx;
        private System.Windows.Forms.TextBox d_main_email_tbx;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button d_main_edit_clinic_b;
        private System.Windows.Forms.TextBox d_main_clinic_address_tbx;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox d_main_clinic_name_combo;
        private System.Windows.Forms.Button d_main_clinic_save_b;
        private System.Windows.Forms.Button d_main_close_b;
        private System.Windows.Forms.Button d_main_general_save_b;
        private System.Windows.Forms.RadioButton d_main_gender_o_rb;
        private System.Windows.Forms.RadioButton d_main_gender_f_rb;
        private System.Windows.Forms.RadioButton d_main_gender_m_rb;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button d_main_editinfo_b;
        private System.Windows.Forms.ComboBox d_main_weekday_combo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox d_main_clinic_combo;
        private System.Windows.Forms.TextBox d_main_clinicID_tbx;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.CheckBox d_main_nositting_cbx;
        private System.Windows.Forms.ListBox Appointments;
        private System.Windows.Forms.DataGridView schedulegrid;
        private System.Windows.Forms.DataGridView doctortimings;
        private System.Windows.Forms.Label label3;
    }
}