﻿namespace project
{
    partial class d_main_page_viewdetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IC_appointed_dtp = new System.Windows.Forms.DateTimePicker();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.dmain_viewdetails_appID_tbx = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dmain_viewdetails_name_tbx = new System.Windows.Forms.TextBox();
            this.IC_prefappdate_dtp = new System.Windows.Forms.DateTimePicker();
            this.dmain_viewdetails_caseID_tbx = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dmain_viewdetails_appStatus_tbx = new System.Windows.Forms.TextBox();
            this.dmain_viewdetails_casetype_tbx = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.IC_specialinstruction_tbx = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.IC_casedetails_tbx = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.IC_dateaccident_label = new System.Windows.Forms.Label();
            this.IC_dateaccident_dtp = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.dmain_viewdetails_editApp_b = new System.Windows.Forms.Button();
            this.dmain_viewdetails_close_b = new System.Windows.Forms.Button();
            this.dmain_viewdetails_gender_tbx = new System.Windows.Forms.TextBox();
            this.dmain_viewdetails_confirmStatus_tbx = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // IC_appointed_dtp
            // 
            this.IC_appointed_dtp.CustomFormat = "yyyy-MM-dd hh:mm";
            this.IC_appointed_dtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.IC_appointed_dtp.Location = new System.Drawing.Point(144, 177);
            this.IC_appointed_dtp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.IC_appointed_dtp.Name = "IC_appointed_dtp";
            this.IC_appointed_dtp.Size = new System.Drawing.Size(263, 22);
            this.IC_appointed_dtp.TabIndex = 67;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(9, 149);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(108, 17);
            this.label44.TabIndex = 68;
            this.label44.Text = "Appointment ID:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(9, 89);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(61, 17);
            this.label43.TabIndex = 69;
            this.label43.Text = "Case ID:";
            // 
            // dmain_viewdetails_appID_tbx
            // 
            this.dmain_viewdetails_appID_tbx.Location = new System.Drawing.Point(144, 145);
            this.dmain_viewdetails_appID_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_appID_tbx.Name = "dmain_viewdetails_appID_tbx";
            this.dmain_viewdetails_appID_tbx.Size = new System.Drawing.Size(261, 22);
            this.dmain_viewdetails_appID_tbx.TabIndex = 66;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(11, 118);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(60, 17);
            this.label41.TabIndex = 72;
            this.label41.Text = "Gender:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(9, 181);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(125, 17);
            this.label40.TabIndex = 73;
            this.label40.Text = "Appointment Date:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(109, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 25);
            this.label1.TabIndex = 74;
            this.label1.Text = "Patient Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 75;
            this.label2.Text = "Full Name:";
            // 
            // dmain_viewdetails_name_tbx
            // 
            this.dmain_viewdetails_name_tbx.Location = new System.Drawing.Point(144, 53);
            this.dmain_viewdetails_name_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_name_tbx.Name = "dmain_viewdetails_name_tbx";
            this.dmain_viewdetails_name_tbx.Size = new System.Drawing.Size(263, 22);
            this.dmain_viewdetails_name_tbx.TabIndex = 76;
            this.dmain_viewdetails_name_tbx.TextChanged += new System.EventHandler(this.dmain_viewdetails_name_tbx_TextChanged);
            // 
            // IC_prefappdate_dtp
            // 
            this.IC_prefappdate_dtp.Location = new System.Drawing.Point(145, 209);
            this.IC_prefappdate_dtp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.IC_prefappdate_dtp.Name = "IC_prefappdate_dtp";
            this.IC_prefappdate_dtp.Size = new System.Drawing.Size(260, 22);
            this.IC_prefappdate_dtp.TabIndex = 77;
            // 
            // dmain_viewdetails_caseID_tbx
            // 
            this.dmain_viewdetails_caseID_tbx.Location = new System.Drawing.Point(144, 85);
            this.dmain_viewdetails_caseID_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_caseID_tbx.Name = "dmain_viewdetails_caseID_tbx";
            this.dmain_viewdetails_caseID_tbx.Size = new System.Drawing.Size(263, 22);
            this.dmain_viewdetails_caseID_tbx.TabIndex = 80;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 245);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 17);
            this.label4.TabIndex = 81;
            this.label4.Text = "Appointment Status:";
            // 
            // dmain_viewdetails_appStatus_tbx
            // 
            this.dmain_viewdetails_appStatus_tbx.Location = new System.Drawing.Point(145, 241);
            this.dmain_viewdetails_appStatus_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_appStatus_tbx.Name = "dmain_viewdetails_appStatus_tbx";
            this.dmain_viewdetails_appStatus_tbx.Size = new System.Drawing.Size(260, 22);
            this.dmain_viewdetails_appStatus_tbx.TabIndex = 82;
            // 
            // dmain_viewdetails_casetype_tbx
            // 
            this.dmain_viewdetails_casetype_tbx.Location = new System.Drawing.Point(145, 300);
            this.dmain_viewdetails_casetype_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_casetype_tbx.Name = "dmain_viewdetails_casetype_tbx";
            this.dmain_viewdetails_casetype_tbx.Size = new System.Drawing.Size(260, 22);
            this.dmain_viewdetails_casetype_tbx.TabIndex = 84;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 304);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 17);
            this.label5.TabIndex = 83;
            this.label5.Text = "Case Type:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.IC_specialinstruction_tbx);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.IC_casedetails_tbx);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.IC_dateaccident_label);
            this.groupBox2.Controls.Add(this.IC_dateaccident_dtp);
            this.groupBox2.Location = new System.Drawing.Point(5, 332);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(403, 199);
            this.groupBox2.TabIndex = 86;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Details";
            // 
            // IC_specialinstruction_tbx
            // 
            this.IC_specialinstruction_tbx.Location = new System.Drawing.Point(143, 121);
            this.IC_specialinstruction_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.IC_specialinstruction_tbx.Name = "IC_specialinstruction_tbx";
            this.IC_specialinstruction_tbx.Size = new System.Drawing.Size(255, 70);
            this.IC_specialinstruction_tbx.TabIndex = 64;
            this.IC_specialinstruction_tbx.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label7.Location = new System.Drawing.Point(8, 124);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 17);
            this.label7.TabIndex = 63;
            this.label7.Text = "Special Instructions:";
            // 
            // IC_casedetails_tbx
            // 
            this.IC_casedetails_tbx.Location = new System.Drawing.Point(143, 50);
            this.IC_casedetails_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.IC_casedetails_tbx.Name = "IC_casedetails_tbx";
            this.IC_casedetails_tbx.Size = new System.Drawing.Size(255, 62);
            this.IC_casedetails_tbx.TabIndex = 52;
            this.IC_casedetails_tbx.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label6.Location = new System.Drawing.Point(8, 50);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 17);
            this.label6.TabIndex = 51;
            this.label6.Text = "Case details:";
            // 
            // IC_dateaccident_label
            // 
            this.IC_dateaccident_label.AutoSize = true;
            this.IC_dateaccident_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.IC_dateaccident_label.Location = new System.Drawing.Point(8, 23);
            this.IC_dateaccident_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.IC_dateaccident_label.Name = "IC_dateaccident_label";
            this.IC_dateaccident_label.Size = new System.Drawing.Size(115, 17);
            this.IC_dateaccident_label.TabIndex = 50;
            this.IC_dateaccident_label.Text = "Date of accident:";
            // 
            // IC_dateaccident_dtp
            // 
            this.IC_dateaccident_dtp.Location = new System.Drawing.Point(143, 18);
            this.IC_dateaccident_dtp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.IC_dateaccident_dtp.Name = "IC_dateaccident_dtp";
            this.IC_dateaccident_dtp.Size = new System.Drawing.Size(255, 22);
            this.IC_dateaccident_dtp.TabIndex = 49;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label3.Location = new System.Drawing.Point(9, 213);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 17);
            this.label3.TabIndex = 87;
            this.label3.Text = "Preferred Date:";
            // 
            // dmain_viewdetails_editApp_b
            // 
            this.dmain_viewdetails_editApp_b.Location = new System.Drawing.Point(5, 542);
            this.dmain_viewdetails_editApp_b.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_editApp_b.Name = "dmain_viewdetails_editApp_b";
            this.dmain_viewdetails_editApp_b.Size = new System.Drawing.Size(221, 28);
            this.dmain_viewdetails_editApp_b.TabIndex = 88;
            this.dmain_viewdetails_editApp_b.Text = "Edit Appointment Time";
            this.dmain_viewdetails_editApp_b.UseVisualStyleBackColor = true;
            this.dmain_viewdetails_editApp_b.Click += new System.EventHandler(this.dmain_viewdetails_editApp_b_Click);
            // 
            // dmain_viewdetails_close_b
            // 
            this.dmain_viewdetails_close_b.Location = new System.Drawing.Point(235, 542);
            this.dmain_viewdetails_close_b.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_close_b.Name = "dmain_viewdetails_close_b";
            this.dmain_viewdetails_close_b.Size = new System.Drawing.Size(172, 28);
            this.dmain_viewdetails_close_b.TabIndex = 89;
            this.dmain_viewdetails_close_b.Text = "Save and Close";
            this.dmain_viewdetails_close_b.UseVisualStyleBackColor = true;
            this.dmain_viewdetails_close_b.Click += new System.EventHandler(this.dmain_viewdetails_close_b_Click);
            // 
            // dmain_viewdetails_gender_tbx
            // 
            this.dmain_viewdetails_gender_tbx.Location = new System.Drawing.Point(144, 114);
            this.dmain_viewdetails_gender_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_gender_tbx.Name = "dmain_viewdetails_gender_tbx";
            this.dmain_viewdetails_gender_tbx.Size = new System.Drawing.Size(261, 22);
            this.dmain_viewdetails_gender_tbx.TabIndex = 90;
            // 
            // dmain_viewdetails_confirmStatus_tbx
            // 
            this.dmain_viewdetails_confirmStatus_tbx.Location = new System.Drawing.Point(145, 271);
            this.dmain_viewdetails_confirmStatus_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dmain_viewdetails_confirmStatus_tbx.Name = "dmain_viewdetails_confirmStatus_tbx";
            this.dmain_viewdetails_confirmStatus_tbx.Size = new System.Drawing.Size(260, 22);
            this.dmain_viewdetails_confirmStatus_tbx.TabIndex = 93;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 274);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(135, 17);
            this.label9.TabIndex = 92;
            this.label9.Text = "Confirmation Status:";
            // 
            // d_main_page_viewdetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 575);
            this.Controls.Add(this.dmain_viewdetails_confirmStatus_tbx);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dmain_viewdetails_gender_tbx);
            this.Controls.Add(this.dmain_viewdetails_close_b);
            this.Controls.Add(this.dmain_viewdetails_editApp_b);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dmain_viewdetails_casetype_tbx);
            this.Controls.Add(this.IC_prefappdate_dtp);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dmain_viewdetails_appStatus_tbx);
            this.Controls.Add(this.dmain_viewdetails_caseID_tbx);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dmain_viewdetails_name_tbx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.IC_appointed_dtp);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.dmain_viewdetails_appID_tbx);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "d_main_page_viewdetails";
            this.Text = "d_main_page_viewdetails";
            this.Load += new System.EventHandler(this.d_main_page_viewdetails_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker IC_appointed_dtp;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox dmain_viewdetails_appID_tbx;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox dmain_viewdetails_name_tbx;
        private System.Windows.Forms.DateTimePicker IC_prefappdate_dtp;
        private System.Windows.Forms.TextBox dmain_viewdetails_caseID_tbx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox dmain_viewdetails_appStatus_tbx;
        private System.Windows.Forms.TextBox dmain_viewdetails_casetype_tbx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox IC_casedetails_tbx;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label IC_dateaccident_label;
        private System.Windows.Forms.DateTimePicker IC_dateaccident_dtp;
        private System.Windows.Forms.RichTextBox IC_specialinstruction_tbx;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button dmain_viewdetails_editApp_b;
        private System.Windows.Forms.Button dmain_viewdetails_close_b;
        private System.Windows.Forms.TextBox dmain_viewdetails_gender_tbx;
        private System.Windows.Forms.TextBox dmain_viewdetails_confirmStatus_tbx;
        private System.Windows.Forms.Label label9;
    }
}