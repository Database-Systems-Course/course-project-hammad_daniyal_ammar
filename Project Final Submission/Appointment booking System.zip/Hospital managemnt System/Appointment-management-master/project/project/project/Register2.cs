﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project
{
    public partial class Register2_Specialization_label : Form
    {
        SqlConnection con1;
        public Access ac;
        public Register2_Specialization_label()
        {
            InitializeComponent();
        }

        private void register1_doctor_rb_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void register2_proceed_b_Click(object sender, EventArgs e)
        {
            
            if (register2_contactno_tbx.TextLength == 9 && register2_emno_tbx.TextLength == 11) {
                if (register2_email_tbx.Text.Contains("@") && register2_email_tbx.Text.Contains("."))
                {
                    if (register2_fname_tbx.TextLength > 0 && register2_contactno_tbx.TextLength > 0 && register2_email_tbx.TextLength > 0 && register2_address_tbx.TextLength > 0)
                    {
                        if (register2_male_rb.Checked || register2_female_rb.Checked || register2_other_rb.Checked)
                        {
                            char gender;
                            string selectDateAsString = register2_dob_dt.Value.ToString("yyyy-MM-dd");
                            if (register2_male_rb.Checked)
                            {
                                gender = 'm';
                            }
                            else if (register2_female_rb.Checked)
                            {
                                gender = 'f';
                            }
                            else
                            {
                                gender = 'o';
                            }
                            SqlCommand cmd = new SqlCommand();
                            SqlCommand cmd2 = new SqlCommand();
                            SqlCommand cmd3 = new SqlCommand();
                            if (register2_doctor_rb.Checked)
                            {
                                cmd.CommandText = "insert into doctor(DoctorName,Gender,DOB,ContactNo,emailID,Address) " +
                                    "values('" + register2_fname_tbx.Text + "','" + gender + "','" + selectDateAsString + "'," + Convert.ToInt32(register2_contactno_tbx.Text) + ",'" + register2_email_tbx.Text
                                    + "','" + register2_address_tbx.Text + "')";
                                cmd2.CommandText = "select @@identity";
                                cmd.Connection = con1;
                                cmd.CommandType = CommandType.Text;
                                cmd2.Connection = con1;
                                cmd2.CommandType = CommandType.Text;
                                cmd.ExecuteScalar();
                                string id = cmd2.ExecuteScalar().ToString();
                                cmd3.CommandText = "insert into Login(Doctor_idDoctor,Username,loginPassword)" +
                                    " values('" + id + "','" + ac.username + "','" + ac.password + "')";
                                cmd3.Connection = con1;
                                cmd3.CommandType = CommandType.Text;
                                cmd3.ExecuteScalar();
                                this.Hide();
                                d_main_page form3 = new d_main_page();
                                form3.doctorID = Convert.ToInt32(id);
                                form3.Closed += (s, args) => this.Close();
                                form3.Show();
                            }
                            else if (register2_patient_rb.Checked)
                            {
                                cmd.CommandText = "insert into Patient(PatientName,Gender,DOB,ContactNo,Address,EmailID, EmergencyContact, EmergencyNumber) " +
                                    "values('" + register2_fname_tbx.Text + "','" + gender + "','" + selectDateAsString + "'," + Convert.ToInt32(register2_contactno_tbx.Text) + ",'" + register2_address_tbx.Text
                                + "','" + register2_email_tbx.Text + "', '" + register2_emname_tbx.Text + "', '" + register2_emno_tbx.Text + "' )";
                                cmd2.CommandText = "select @@identity";
                                cmd.Connection = con1;
                                cmd.CommandType = CommandType.Text;
                                cmd2.Connection = con1;
                                cmd2.CommandType = CommandType.Text;
                                cmd.ExecuteScalar();
                                string id = cmd2.ExecuteScalar().ToString();
                                cmd3.CommandText = "insert into Login(Patient_idPatient,Username,loginPassword)" +
                                    " values('" + id + "','" + ac.username + "','" + ac.password + "')";
                                cmd3.Connection = con1;
                                cmd3.CommandType = CommandType.Text;
                                cmd3.ExecuteScalar();
                                this.Hide();
                                p_main_page form4 = new p_main_page();
                                form4.patientID = Convert.ToInt32(id);
                                form4.Closed += (s, args) => this.Close();
                                form4.Show();
                            }
                            else
                            {
                                MessageBox.Show("you must select your registration type");
                            }
                        }
                        else
                        {
                            MessageBox.Show("you must select your gender");
                        }
                    }
                    else
                    {
                        MessageBox.Show("please fill out the empty fields");
                    }
                }

                else
                {
                    MessageBox.Show("Invalid Email Entered.");
                }
            }
            else
            {
                MessageBox.Show("Invalid Contact/ Emergency Number");
            }

        }
        public void setAccess(Access a)
        {
            this.ac = a;
        }

        private void Register2_Load(object sender, EventArgs e)
        {
            //con1 = new SqlConnection("Data Source =.; Initial Catalog = PMS; User ID = sa; Password=Habib123##"); 
            con1 = new SqlConnection(@"Data Source=DESKTOP-PGBON6F;Initial Catalog=AppointmentProj;Integrated Security=SSPI;User ID=DESKTOP-PGBON6F\HP;Password=");
            //public SqlCommand cmd = new SqlCommand(); 
            con1.Open();
        }

        private void register2_address_tbx_TextChanged(object sender, EventArgs e)
        {

        }

        private void register2_emname_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void register2_fname_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void register2_emno_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void register2_email_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void register2_contactno_tbx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
