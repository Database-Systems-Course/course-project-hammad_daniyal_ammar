﻿namespace project
{
    partial class Register1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.regiser1_welcome_label = new System.Windows.Forms.Label();
            this.register1_username_label = new System.Windows.Forms.Label();
            this.register1_password_label = new System.Windows.Forms.Label();
            this.register1_username_tbx = new System.Windows.Forms.MaskedTextBox();
            this.register1_password_tbx = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.register1_proceed_b = new System.Windows.Forms.Button();
            this.register1_retype_tbx = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // regiser1_welcome_label
            // 
            this.regiser1_welcome_label.AutoSize = true;
            this.regiser1_welcome_label.Location = new System.Drawing.Point(16, 11);
            this.regiser1_welcome_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.regiser1_welcome_label.Name = "regiser1_welcome_label";
            this.regiser1_welcome_label.Size = new System.Drawing.Size(222, 17);
            this.regiser1_welcome_label.TabIndex = 1;
            this.regiser1_welcome_label.Text = "Fill in the form below to Register :)";
            // 
            // register1_username_label
            // 
            this.register1_username_label.AutoSize = true;
            this.register1_username_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register1_username_label.Location = new System.Drawing.Point(16, 46);
            this.register1_username_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.register1_username_label.Name = "register1_username_label";
            this.register1_username_label.Size = new System.Drawing.Size(81, 18);
            this.register1_username_label.TabIndex = 5;
            this.register1_username_label.Text = "Username:";
            // 
            // register1_password_label
            // 
            this.register1_password_label.AutoSize = true;
            this.register1_password_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register1_password_label.Location = new System.Drawing.Point(16, 85);
            this.register1_password_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.register1_password_label.Name = "register1_password_label";
            this.register1_password_label.Size = new System.Drawing.Size(79, 18);
            this.register1_password_label.TabIndex = 6;
            this.register1_password_label.Text = "Password:";
            // 
            // register1_username_tbx
            // 
            this.register1_username_tbx.Location = new System.Drawing.Point(115, 39);
            this.register1_username_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.register1_username_tbx.Name = "register1_username_tbx";
            this.register1_username_tbx.Size = new System.Drawing.Size(259, 22);
            this.register1_username_tbx.TabIndex = 7;
            this.register1_username_tbx.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.register1_username_tbx_MaskInputRejected);
            // 
            // register1_password_tbx
            // 
            this.register1_password_tbx.Location = new System.Drawing.Point(115, 79);
            this.register1_password_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.register1_password_tbx.Name = "register1_password_tbx";
            this.register1_password_tbx.PasswordChar = '*';
            this.register1_password_tbx.Size = new System.Drawing.Size(259, 22);
            this.register1_password_tbx.TabIndex = 8;
            this.register1_password_tbx.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(383, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "min 4 characters";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(383, 87);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "min 6 characters";
            // 
            // register1_proceed_b
            // 
            this.register1_proceed_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.register1_proceed_b.Location = new System.Drawing.Point(384, 110);
            this.register1_proceed_b.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.register1_proceed_b.Name = "register1_proceed_b";
            this.register1_proceed_b.Size = new System.Drawing.Size(112, 36);
            this.register1_proceed_b.TabIndex = 13;
            this.register1_proceed_b.Text = "Proceed";
            this.register1_proceed_b.UseVisualStyleBackColor = true;
            this.register1_proceed_b.Click += new System.EventHandler(this.register1_proceed_b_Click);
            // 
            // register1_retype_tbx
            // 
            this.register1_retype_tbx.Location = new System.Drawing.Point(115, 110);
            this.register1_retype_tbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.register1_retype_tbx.Name = "register1_retype_tbx";
            this.register1_retype_tbx.PasswordChar = '*';
            this.register1_retype_tbx.Size = new System.Drawing.Size(259, 22);
            this.register1_retype_tbx.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 116);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 18);
            this.label3.TabIndex = 14;
            this.label3.Text = "Retype:";
            // 
            // Register1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 151);
            this.ControlBox = false;
            this.Controls.Add(this.register1_retype_tbx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.register1_proceed_b);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.register1_password_tbx);
            this.Controls.Add(this.register1_username_tbx);
            this.Controls.Add(this.register1_password_label);
            this.Controls.Add(this.register1_username_label);
            this.Controls.Add(this.regiser1_welcome_label);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Register1";
            this.Text = "Sign Up";
            this.Load += new System.EventHandler(this.Register1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label regiser1_welcome_label;
        private System.Windows.Forms.Label register1_username_label;
        private System.Windows.Forms.Label register1_password_label;
        private System.Windows.Forms.MaskedTextBox register1_username_tbx;
        private System.Windows.Forms.MaskedTextBox register1_password_tbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button register1_proceed_b;
        private System.Windows.Forms.MaskedTextBox register1_retype_tbx;
        private System.Windows.Forms.Label label3;
    }
}