--Read me
1. Restore the database using the backup file given. (mwams.bak)
2. Reset the connection string according to your PC.
3. Run the visual studio file.
4. You can register yourself as a doctor or a patient. (not both)
5. The patient instructs a case according to their needs and prefrences.
6. The doctor can choose to appoint the patient.
7. The patient can check if a particular doctor has appointed them,
   the patient can choose to accept or decline the appointment.